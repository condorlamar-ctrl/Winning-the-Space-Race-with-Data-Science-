import pandas as pd
from dash import Dash, dcc, html, Input, Output
import plotly.express as px

df = pd.read_csv('synthetic_spacex_falcon9_dataset.csv')
app = Dash(__name__)
app.layout = html.Div([
    html.H1('Synthetic Falcon 9 Launch Dashboard'),
    html.P('Educational data only — not official SpaceX history.'),
    dcc.Dropdown(sorted(df.LaunchSite.unique()), sorted(df.LaunchSite.unique()), multi=True, id='site'),
    dcc.RangeSlider(int(df.PayloadMassKg.min()), int(df.PayloadMassKg.max()), value=[int(df.PayloadMassKg.min()), int(df.PayloadMassKg.max())], id='payload'),
    dcc.Graph(id='outcomes'), dcc.Graph(id='scatter')
])
@app.callback([Output('outcomes','figure'), Output('scatter','figure')], [Input('site','value'), Input('payload','value')])
def update(sites, payload):
    d = df[df.LaunchSite.isin(sites) & df.PayloadMassKg.between(payload[0], payload[1])]
    return (px.pie(d, names='Class', title='Landing outcome share'), px.scatter(d, x='PayloadMassKg', y='Class', color='LaunchSite', hover_data=['Orbit','Block']))
if __name__ == '__main__':
    app.run(debug=True)
