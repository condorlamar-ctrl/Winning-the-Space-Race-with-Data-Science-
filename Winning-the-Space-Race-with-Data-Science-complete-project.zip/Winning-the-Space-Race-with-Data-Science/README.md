# Winning the Space Race with Data Science

## Important disclosure
This repository uses a **synthetic educational dataset**. It is not official SpaceX data and must not be used to make claims about actual SpaceX performance.

## Contents
- `01_spacex_api_collection.ipynb` — collection schema and quality checks
- `02_web_scraping.ipynb` — completed BeautifulSoup workflow
- `03_data_wrangling.ipynb` — data cleaning and feature preparation
- `04_eda_visualization.ipynb` — EDA charts and findings
- `05_eda_sql.ipynb` — SQLite queries and results
- `06_folium_map.ipynb` — interactive Folium marker map
- `07_classification_model.ipynb` — classification workflow and evaluation
- `app.py` — Plotly Dash dashboard

## Run
```bash
pip install -r requirements.txt
python app.py
```

Open each notebook in Jupyter Notebook or JupyterLab.
